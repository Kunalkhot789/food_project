#lists in python
list=[]
print(list)

single_dimensional_list=["name",1,2]
print(single_dimensional_list)
print(single_dimensional_list[0])


Multi_dimensional_list=[[1,2,3,4],["shekhar","pasupathi","kartik"]]
print(Multi_dimensional_list)
print(Multi_dimensional_list[0][3]) 
print(Multi_dimensional_list[1][0]) 
print(Multi_dimensional_list[1][2]) 
