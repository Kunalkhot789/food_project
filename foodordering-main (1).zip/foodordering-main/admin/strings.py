stringname="shekhar"
print("inital string ")
print(stringname)

print("the first character of string is :")
print(stringname[0])


print("the last character of string is :")
print(stringname[-1])