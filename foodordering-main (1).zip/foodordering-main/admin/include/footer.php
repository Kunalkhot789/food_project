 <footer class="footer" style="text-align: center;"> Developed by shekhar padhy © 2024 - <a href="www.aarohikitchens.com">Shekhar padhy</a> </footer>

 